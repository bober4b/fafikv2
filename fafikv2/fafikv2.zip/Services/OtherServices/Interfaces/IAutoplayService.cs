﻿namespace Fafikv2.Services.OtherServices.Interfaces
{
    public interface IAutoplayService
    {

    }
}
